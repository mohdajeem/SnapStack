// import serverless from "serverless-http";
// import dotenv from 'dotenv';
// import { connectDb } from './config/db.js';

// // Load env as early as possible so modules that run before importing app
// // (for example connectDb called below) have access to environment variables.
// dotenv.config();

// const PORT = 5000;
// connectDb();

// // Dynamically import the app so we can catch import-time errors (such as
// // malformed route strings) and log them with context before proceeding.
// let app;
// try {
//   const mod = await import('./app.js');
//   app = mod.app;
// } catch (err) {
//   console.error('Failed to import ./app.js:', err && err.stack ? err.stack : err);
//   // rethrow so the process exits and the error is visible to the caller
//   throw err;
// }

// // app.listen(PORT, () => {
// //     console.log(`server is running on the port http://localhost:${PORT}`);
// // })
// // Export handler for AWS Lambda
// try {
//   console.log('Creating serverless handler for app...');
//   module.exports.handler = serverless(app);
// } catch (err) {
//   console.error('Error creating serverless handler:', err && err.stack ? err.stack : err);
//   throw err;
// }

// // Optional local run (for local testing)
// if (process.env.NODE_ENV !== 'lambda') {
//   const port = process.env.PORT || 5000;
//   app.listen(port, () => console.log(`Server running locally on port ${port}`));
// }




import serverless from 'serverless-http';
import dotenv from 'dotenv';
import { connectDb } from './config/db.js';
import { app } from './app.js';

dotenv.config();

// Connect MongoDB
connectDb();

// Start local server or export for Lambda
const PORT = process.env.PORT || 5000;

if (process.env.NODE_ENV !== 'lambda') {
  app.listen(PORT, () => console.log(`Server running locally on port ${PORT}`));
}

// Export handler for AWS Lambda
export const handler = serverless(app);
